package handlers

import (
	"context"
	"fmt"
	"os"
	"time"

	"github.com/ailtonbrc/msd/server/database"
	"github.com/ailtonbrc/msd/server/models"
	"github.com/gofiber/fiber/v2"
	"github.com/golang-jwt/jwt/v5"
	"golang.org/x/crypto/bcrypt"
)

func Login(c *fiber.Ctx) error {
	var loginData struct {
		Email  string `json:"email"`
		Senha  string `json:"senha"`
	}

	if err := c.BodyParser(&loginData); err != nil {
		return c.Status(fiber.StatusBadRequest).JSON(fiber.Map{"erro": "Dados inválidos"})
	}

	var usuario models.Usuario
	query := "SELECT id, nome, email, senha, perfil, clinica_id FROM usuarios WHERE email = $1"
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	err := database.DB.QueryRow(ctx, query, loginData.Email).Scan(
		&usuario.ID,
		&usuario.Nome,
		&usuario.Email,
		&usuario.Senha,
		&usuario.Perfil,
		&usuario.ClinicaID,
	)

	if err != nil {
		fmt.Println("Erro ao buscar usuário:", err)
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"erro": "Usuário ou senha inválidos"})
	}

	if err := bcrypt.CompareHashAndPassword([]byte(usuario.Senha), []byte(loginData.Senha)); err != nil {
		return c.Status(fiber.StatusUnauthorized).JSON(fiber.Map{"erro": "Usuário ou senha inválidos"})
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, jwt.MapClaims{
		"id":         usuario.ID,
		"nome":       usuario.Nome,
		"email":      usuario.Email,
		"perfil":     usuario.Perfil,
		"clinica_id": usuario.ClinicaID,
		"exp":        time.Now().Add(time.Hour * 72).Unix(),
	})

	secret := os.Getenv("JWT_SECRET")
	tokenString, err := token.SignedString([]byte(secret))
	if err != nil {
		return c.Status(fiber.StatusInternalServerError).JSON(fiber.Map{"erro": "Erro ao gerar token"})
	}

	return c.JSON(fiber.Map{
		"token": tokenString,
	})
}