package routes

import (
	"github.com/ailtonbrc/msd/server/handlers"
	"github.com/gofiber/fiber/v2"
)

func SetupAuthRoutes(app fiber.Router) {
	auth := app.Group("/auth")
	auth.Post("/login", handlers.Login)
}