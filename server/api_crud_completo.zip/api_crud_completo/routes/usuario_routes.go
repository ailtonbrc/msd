package routes

import (
	"github.com/ailtonbrc/msd/server/handlers"
	"github.com/gofiber/fiber/v2"
)

func SetupUsuarioRoutes(app fiber.Router) {
	usuario := app.Group("/usuarios")
	usuario.Get("/", handlers.ListarUsuarios)
	usuario.Get("/:id", handlers.BuscarUsuario)
	usuario.Put("/:id", handlers.AtualizarUsuario)
	usuario.Delete("/:id", handlers.DeletarUsuario)
}