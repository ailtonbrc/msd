package routes

import (
	"github.com/ailtonbrc/msd/server/handlers"
	"github.com/gofiber/fiber/v2"
)

func SetupClinicaRoutes(app fiber.Router) {
	clinica := app.Group("/clinicas")
	clinica.Get("/", handlers.ListarClinicas)
	clinica.Get("/:id", handlers.BuscarClinica)
	clinica.Put("/:id", handlers.AtualizarClinica)
	clinica.Delete("/:id", handlers.DeletarClinica)
}