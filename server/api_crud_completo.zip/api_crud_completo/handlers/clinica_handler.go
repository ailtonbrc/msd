package handlers

import (
	"context"
	"fmt"
	"time"

	"github.com/ailtonbrc/msd/server/database"
	"github.com/ailtonbrc/msd/server/models"
	"github.com/gofiber/fiber/v2"
)

func ListarClinicas(c *fiber.Ctx) error {
	rows, err := database.DB.Query(context.Background(), "SELECT id, nome, cnpj, endereco, telefone FROM clinicas")
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"erro": "Erro ao buscar clínicas"})
	}
	defer rows.Close()

	var clinicas []models.Clinica
	for rows.Next() {
		var cl models.Clinica
		if err := rows.Scan(&cl.ID, &cl.Nome, &cl.CNPJ, &cl.Endereco, &cl.Telefone); err == nil {
			clinicas = append(clinicas, cl)
		}
	}
	return c.JSON(clinicas)
}

func BuscarClinica(c *fiber.Ctx) error {
	id := c.Params("id")
	var cl models.Clinica
	err := database.DB.QueryRow(context.Background(), "SELECT id, nome, cnpj, endereco, telefone FROM clinicas WHERE id = $1", id).Scan(&cl.ID, &cl.Nome, &cl.CNPJ, &cl.Endereco, &cl.Telefone)
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"erro": "Clínica não encontrada"})
	}
	return c.JSON(cl)
}

func AtualizarClinica(c *fiber.Ctx) error {
	id := c.Params("id")
	var cl models.Clinica
	if err := c.BodyParser(&cl); err != nil {
		return c.Status(400).JSON(fiber.Map{"erro": "Dados inválidos"})
	}
	query := `
		UPDATE clinicas SET nome=$1, cnpj=$2, endereco=$3, telefone=$4
		WHERE id=$5
	`
	_, err := database.DB.Exec(context.Background(), query, cl.Nome, cl.CNPJ, cl.Endereco, cl.Telefone, id)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"erro": "Erro ao atualizar clínica"})
	}
	return c.SendStatus(204)
}

func DeletarClinica(c *fiber.Ctx) error {
	id := c.Params("id")
	_, err := database.DB.Exec(context.Background(), "DELETE FROM clinicas WHERE id=$1", id)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"erro": "Erro ao deletar clínica"})
	}
	return c.SendStatus(204)
}