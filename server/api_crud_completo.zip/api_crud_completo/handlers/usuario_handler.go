package handlers

import (
	"context"
	"fmt"
	"time"

	"github.com/ailtonbrc/msd/server/database"
	"github.com/ailtonbrc/msd/server/models"
	"github.com/gofiber/fiber/v2"
	"golang.org/x/crypto/bcrypt"
)

func ListarUsuarios(c *fiber.Ctx) error {
	rows, err := database.DB.Query(context.Background(), "SELECT id, nome, email, perfil, clinica_id, supervisor_id, ativo, data_inicio_inatividade, data_fim_inatividade, motivo_inatividade FROM usuarios")
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"erro": "Erro ao buscar usuários"})
	}
	defer rows.Close()

	var usuarios []models.Usuario
	for rows.Next() {
		var u models.Usuario
		if err := rows.Scan(&u.ID, &u.Nome, &u.Email, &u.Perfil, &u.ClinicaID, &u.SupervisorID, &u.Ativo, &u.DataInicioInatividade, &u.DataFimInatividade, &u.MotivoInatividade); err == nil {
			usuarios = append(usuarios, u)
		}
	}
	return c.JSON(usuarios)
}

func BuscarUsuario(c *fiber.Ctx) error {
	id := c.Params("id")
	var u models.Usuario
	query := "SELECT id, nome, email, perfil, clinica_id, supervisor_id, ativo, data_inicio_inatividade, data_fim_inatividade, motivo_inatividade FROM usuarios WHERE id = $1"
	err := database.DB.QueryRow(context.Background(), query, id).Scan(&u.ID, &u.Nome, &u.Email, &u.Perfil, &u.ClinicaID, &u.SupervisorID, &u.Ativo, &u.DataInicioInatividade, &u.DataFimInatividade, &u.MotivoInatividade)
	if err != nil {
		return c.Status(404).JSON(fiber.Map{"erro": "Usuário não encontrado"})
	}
	return c.JSON(u)
}

func AtualizarUsuario(c *fiber.Ctx) error {
	id := c.Params("id")
	var u models.Usuario
	if err := c.BodyParser(&u); err != nil {
		return c.Status(400).JSON(fiber.Map{"erro": "Dados inválidos"})
	}
	query := `
		UPDATE usuarios SET nome=$1, email=$2, perfil=$3, clinica_id=$4, supervisor_id=$5, ativo=$6, data_inicio_inatividade=$7, data_fim_inatividade=$8, motivo_inatividade=$9
		WHERE id=$10
	`
	_, err := database.DB.Exec(context.Background(), query, u.Nome, u.Email, u.Perfil, u.ClinicaID, u.SupervisorID, u.Ativo, u.DataInicioInatividade, u.DataFimInatividade, u.MotivoInatividade, id)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"erro": "Erro ao atualizar usuário"})
	}
	return c.SendStatus(204)
}

func DeletarUsuario(c *fiber.Ctx) error {
	id := c.Params("id")
	_, err := database.DB.Exec(context.Background(), "DELETE FROM usuarios WHERE id=$1", id)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"erro": "Erro ao deletar usuário"})
	}
	return c.SendStatus(204)
}