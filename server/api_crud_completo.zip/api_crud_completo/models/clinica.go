package models

type Clinica struct {
	ID       int    `json:"id"`
	Nome     string `json:"nome"`
	CNPJ     string `json:"cnpj"`
	Endereco string `json:"endereco"`
	Telefone string `json:"telefone"`
}